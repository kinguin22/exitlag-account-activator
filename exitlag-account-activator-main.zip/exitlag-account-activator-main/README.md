# Exitlag Account Activator
<img src="https://www.exitlag.com/img/exitlag.svg" width=120>

 Activate exitlag trial accounts (unlimited trial accounts)

## ⭐If you want to support, follow me on github and star the project.⭐

<img src="https://user-images.githubusercontent.com/53904508/128664596-e908f0d1-c222-47f4-8ce4-53d368e281cb.png">

## DISCLAIMER
This script was created for educational purposes only, I am not responsible for how this program is being used.

## REQUIREMENTS
1. A Brain
2. Python Installed
 
## Features Exitlag Account Activator:
1. Resets Trial (Unlimited usage)<br />
2. Easy to Use.<br />

## How to use Exitlag Account Activator:
- Download and install <a href="https://www.python.org/downloads/">python</a> and <a href="https://exitlag.com">exitlag</a>.
- Download <a href="https://github.com/gato-louco/exitlag-account-activator/blob/main/main.py">main.py</a> to your Downloads folder.
- Create a account on exitlag with the password `gatolouco`
- You can use a TEMP MAIL or check <a href="https://github.com/gato-louco/exitlag-account-activator/issues/12">#12</a> to create temp mails for Exitlag.
- Now open CMD and type `pip install websockets` to install the module.
- After that type `python Downloads/main.py` or add the location if your files download somewhere else.
- Type the account's email and press return.
- It should activate the account and you will get free access to exitlag for 3 days.
- Now simply login using the email in exitlag software that you have downloaded earlier.

## Important:
- Check issue <a href="https://github.com/gato-louco/exitlag-account-activator/issues/12">#12</a> if you get problem related to TEMP MAIL


## Have a nice day :)
